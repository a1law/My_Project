import sys
import functions

def test_list_to_str():
    assert functions.list_to_str(['hi', 'angie', 'lol']) == 'hi angie lol '
    assert functions.list_to_str(['how','are','you','?']) == 'how are you ? '
    assert functions.list_to_str(['hello','there','#3']) == 'hello there #3 '

def test_return_topics():
    assert functions.return_topics('hello',['hello', 'there'],'bye') == 'bye'
    assert functions.return_topics('peace',['peace', 'harmony','love'], 'synonyms') == 'synonyms'
    assert functions.return_topics('red',['red','blue','green','orange'], 'colors') == 'colors'
    
def test_print_keys():
    assert functions.print_keys({'hello':'goodbye','hi':'bye'}) == 'hello, hi'
    assert functions.print_keys({'car':'Lexus','color':'black','year':'2019'}) == 'car, color, year'
    assert functions.print_keys({'ucsd':'san diego','ucd':'davis','ucsc':'santa cruz'}) == 'ucsd, ucd, ucsc'