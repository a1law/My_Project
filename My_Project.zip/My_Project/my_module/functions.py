import string


def print_introduction():
    """Print introduction of Sixth College Front Office chatbot"""
    
    print('Welcome to Sixth College Front Office! \n')
    print('Please sign in by entering your name. \n')
    print('-'*38)
    print('Enter "exit" to exit the chat. \n')
    

name_list = [""]

def sign_in():
    """Ask user to input name"""
    
    msg = input('\n' + 'Name: ')
    
    #print introduction with name inputted
    print("\n" + "Sixth Front Desk: Hello " + msg + "! What would you like to"\
          " learn about? \n" + ' '*18 + "Input 'topics' to see the possible "\
          "options." + "\n")
    
    #assign name to name_list
    name_list[0] = msg
    
    
#function from Lecture 22    
def get_input():
    """Ask user for input/question"""
    
    msg = input('\n' + 'Your Response: \t')
    out_msg = None
    
    return msg, out_msg


#modified function from A3 
def remove_punctuation(input_string):
    """Removes punctuation (except question mark) of input """
    
    out_string = ''
    for char in input_string:
        
        if char not in string.punctuation or char == '?':
            out_string += char
            
    return out_string


#A3 function
def prepare_text(input_string):
    """Prepares the text of the input for processing"""
    
    temp_string = input_string.lower()
    temp_string = remove_punctuation(temp_string)
    out_list = temp_string.split()
    
    return out_list


#modified output of function from A3
def end_chat(input_list):
    """Identify if user says 'exit' in input and end chat"""
    
    if 'exit' in input_list:
        output = "Thank you for contacting Sixth College Front Desk, "\
        + list_to_str(name_list) + ". Have a nice day!"
        chat = False
    else:
        output = None
        chat = True
    
    return output, chat


def print_keys(return_dict):
    """Print keys in a specific format"""
    
    # removes 'dict_keys9([''])' and print keys
    for element in return_dict:
        output = str(return_dict.keys()) 
        output = output.replace('dict_keys([','')
        output = output.replace('])','')
        output = output.replace("'","")
        return output
    
    
def return_topics(word, input_list, return_dict):
    "Return return_dict if word is in input_str"
    
    if word in input_list:
        return return_dict

    
#A3 function    
def is_in_list(list_one, list_two):
    """Check if any element of list_one is in list_two."""
    
    for element in list_one:
        if element in list_two:
            return True
    return False


#A3 function
def find_in_list(list_one, list_two):
    """Find and return an element from list_one that is in list_two, 
       or None otherwise."""
    
    for element in list_one:
        if element in list_two:
            return element
    return None


#adapted code of A3 to be considered as part of my graded project
def return_description(msg, out_msg):
    """Responses for chatbot to return"""
    
    #if there is no input, a msg will be returned
    if len(msg) == 0:
        out = []
        out.append("Please input 'topics' or one of the listed topics.")
        return out
    
    #if there is no output
    if not out_msg:
        
        out = []
        
        #and the input is 'topics', 
        #msg will return with listed topics
        if msg[0] == 'topics':
            out.append(return_topics('topics', msg, print_keys(TOPICS)))
            
        #if input is one of the topics listed,
        #msg will return with information relating to the topic
        for name in TOPIC_NAMES:
            if is_in_list(msg, prepare_text(name)):
                key = name
                out.append(TOPICS[key])
                
        #if input does not match any of the topic names,
        #a msg will be returned
        if len(out) == 0:
            out.append("Please input 'topics' or one of the listed topics.")
            
        #if input has a question, a msg will be returned
        for element in msg:
            if '?' in element:
                out.append(UNKNOWN)
                
        return out
    

#updated functionality of A3 function to be considered as part of my grade
def list_to_str(input_list):
    """Puts all element of list into one string"""
    
    out_str = ""
    
    for element in input_list:
        out_str = out_str + element + " "
    
    return out_str


TOPIC_NAMES = ["Sixth College Advising", "Four Year Plans", "GE Requirements",\
               "University Requirements", "Academic Resources",\
               "Applying for Graduation", "Contact", "Other"]

TOPICS = {"Sixth College Advising" : "\n"\
          +"At Sixth College, our academic "\
          +"advising mission is to provide a supportive environment for"\
          +" students to develop and advance their educational, professional,"\
          +" and personal goals. You can submit brief, non-urgent questions "\
          +"through the VAC. Questions submitted to Sixth College are "\
          +"answered by an advisor within 48 business hours. 15-minute "\
          +"walk-in advising sessions are available if you have general "\
          +"questions. 30-minute appointments are recommended for questions "\
          +"or concerns that may require more in-depth advising or complexity"\
          +". To schedule an appointment call the Sixth College Front Desk at"\
          +" (858) 534-9001.",
          
          "Four Year Plans" : "\n"\
          +"Academic Plans are designed to assist you in "\
          +"long-term academic planning. They provide an overview of the "\
          +"recommended course schedules to facilitate graduation from UC San"\
          +"Diego in four years for any major. Please take into consideration"\
          +" that major requirements and time-to-degree varies per individual"\
          +". Plans should be used as a guide only; we highly encourage you "\
          +"to consult with your major department advisor to obtain in-depth "\
          +"advising about your major. In addition, plans do not guarantee "\
          +"that courses will be offered in the quarters listed. If you have"\
          +" further questions regarding your long-term academic plan, "\
          +"contact Sixth College Academic Advising via the Virtual Advising"\
          +" Center or make an appointment for long-term planning by calling "\
          +"(858) 534-9001.",
          
          "GE Requirements" : "\n"\
          +"If you were admitted as a freshman student you"\
          +" must plan to complete the following general education "\
          +"requirements for Sixth College. If admitted as a transfer student"\
          +" you must plan to complete the upper-division general education "\
          +" requirements listed below; additional general education courses "\
          +"may be required based on your transfer agreement. All students "\
          +"must meet Sixth College GE requirements in addition to University"\
          +" Requirements. " + " "*13 +"\n"\
          +"\n-Freshman Core Sequence (3 Courses)"\
          +"\n-Information Technology Fluency (1 Course)"\
          +"\n-Social Analysis (2 Social Science Courses)"\
          +"\n-Narrative, Aesthetic and Historical Reasoning (2 Humanities "\
          +"Courses)"
          +"\n-Analytic Methodologies/Scientific Method (2 Science Courses)"\
          +"\n-Exploring Data (1 Statistics Course)"\
          +"\n-Structured Reasoning (1 Math/Logic Course)"\
          +"\n-Art Making (8 units)"\
          +"\n-UPPER DIVISION REQUIREMENTS (2 courses)"\
          +"\n  -Practicum Course/Project (4 units)"\
          +"\n  -CAT 125/125R: Public Rhetoric and Practical Communication"\
          +" (4 units)",
          
          "University Requirements" : "\n"\
          +"Entry Level Writing Requirement (ELWR)"\
          +"\n The University of California requires all undergraduate "\
          +"students (including international students) to demonstrate a "\
          +"minimum proficiency in English composition within three quarters"\
          +" of entering the University." + "\n"\
          +"\nAmerican History and Institutions (AHI) Requirement" 
          +"\n---Knowledge of American history and of the principles of "\
          +"American institutions under the federal and state constitutions "\
          +"is required of all candidates for a bachelor's degree."\
          +"\nDiversity, Equity, and Inclusion (DEI) Requirement"\
          +"\n---A knowledge of diversity, equity, and inclusion is "\
          +"required of all candidates for a Bachelor's degree who begin "\
          +" UC San Diego in lower-division standing in Fall 2011 or "\
          +"their studies at thereafter, or in upper-division standing in "\
          +"Fall 2013 or thereafter."\
          +"\nMajor Requirements"
          +"\n---Requires twelve or more 4.0-unit, upper-division courses in "\
          +"addition to lower-division prerequisites for the major.",
          
          "Academic Resources" : "\n"\
          +"Academic Resources"\
          +"\n       Sixth College Academic Advising | 858-534-9001"\
          +"\n       Academic Departments and Programs"\
          +"\n       Virtual Advising Center (VAC)"\
          +"\n       Quarter by Quarter Planning Form"\
          +"\nTutoring and Learning Resources"\
          +"\n       Tutoring and Study Programs by Department"\
          +"\n       Writing + Critical Expression Hub | 858-534-4911"\
          +"\n       Teaching & Learning Commons Supplemental Instruction"\
          +"\n       Triton Achievement Partners – Tutoring | 858-534-2466"\
          +"\n       Office of Academic Support & Instructional Services "\
          +"(OASIS) | 858-534-3760"\
          +"\n       Calculus Tutor Lab"\
          +"\n       Physics Tutorial Center"\
          +"\n       Chemistry Help Room"\
          +"\n       Jacobs School of Engineering IDEA Student Center Study "\
          +"Lab"\
          +"\nHealth and Wellness"\
          +"\n       Counseling and Psychological Services (CAPS) | "\
          +"858-534-3755"\
          +"\n       Office of Students with Disabilities (OSD) | "\
          +"858-534-4382"\
          +"\n       Student Health Services | 858-534-3300"\
          +"\n       The Zone | 858-534-5553"\
          +"\n       UCSD Recreation | 858-534-4037"\
          +"\n       CARE at SARC | 858-534-5793"\
          +"\nCampus Community Centers"\
          +"\n       Asian Pacific Islander Middle Eastern Desi American "\
          +"\n      (APIMEDA) Programs and Services | 858-822-0525"\
          +"\n       Black Resource Center | 858-534-0471"\
          +"\n       Cross-Cultural Center | 858-534-9689"\
          +"\n       International Center | 858-534-3730"\
          +"\n       Intertribal Resource Center | 858-822-0048"\
          +"\n       LGBT Resource Center | 858-822-3493"\
          +"\n       Raza Resource Centro | 858-822-0072"\
          +"\n       Student Veterans Resource Center | 858-534-5080"\
          +"\n       Women’s Center | 858-822-0074",
          
 
          "Applying for Graduation" : "\n"\
          +"-Before applying, review your Degree Audit Report on TritonLink "\
          +"to ensure all graduation requirements are complete. For questions"\
          +"regarding general education or University requirements, contact "\
          +"Sixth College Academic Advising. For questions regarding your "\
          +"major or minor requirements, contact the appropriate department. "\
          +"It is recommended to do a graduation check-in meeting with each "\
          +"department the quarter prior to your graduation." + "\n"\
          +"-Verify that your name, permanent address, major and minors are "\
          +"reflected accurately in TritonLink." + "\n"\
          +"-Once you have verified that all graduation requirements will be "\
          +"completed by your intended quarter of graduation, submit your "\
          +"Degree and Diploma Application (DDA) online by the deadlines "\
          +"below:"\
          +"\n     Fall graduates: Last day of finals week, Fall Quarter"\
          +"\n     Winter graduates: Last day of finals week, Winter Quarter"\
          +"\n     Spring graduates: Last day of finals week, Spring Quarter"\
          +"\n     Summer graduates: Last day of finals week, Summer Session "\
          +"II" + "\n"\
          +"To have your name listed in the Commencement program, you must "\
          +"apply no later than May 1st." +"\n"\
          +"To retract or change your application for graduation, contact a"\
          +"Sixth College academic advisor via the Virtual Advising Center.",
          
          "Contact": "\n"\
          +"Contact Sixth College"\
          +"\n      Phone: (858) 534-1481"\
          +"\n      sixthfrontdesk@ucsd.edu"\
          +"\n      Pepper Canyon Hall, 2nd floor"\
          +"\nContact Academic Advising"\
          +"\n      vac.ucsd.edu"\
          +"\nMailing Address"\
          +"\n      Sixth College"\
          +"\n      9500 Gilman Drive"\
          +"\n      Mail Code 0054"\
          +"\n      La Jolla, CA 92093-0054",
          
          
          "Other": "Please visit sixth.ucsd.edu for more information or "\
          +"contact Sixth College Front Desk."}

UNKNOWN = "I'm sorry, I am unable to answer that. \n                  " + \
          "Please try calling (858) 534-1481 or submitting your question" +\
          " to the VAC."


#modified code from A3 to be considered as part of my grade
def sixth_chat():
    """Main function to run our chatbot."""
    
    print_introduction()
    
    sign_in()
    
    chat = True
    while chat:
        
        #takes an input
        msg, out_msg = get_input()
        
        #prepares the text
        msg = prepare_text(msg)
        
        #check if input ends chat
        out_msg, chat = end_chat(msg) 
        
        #returns goodbye msg if input ends chat
        if chat == False:
            print(out_msg)
            return
        
        #specify what to return
        out_msg = return_description(msg, out_msg)
        
        #turn list to string
        out_str = list_to_str(out_msg)
            
        print('\n' + 'Sixth Front Desk: ', out_str + '\n')
        
        
#sixth_chat()
